PredictionModel(32, 100, 2, 32, 32, 32, 0.00001) -> 0.002717
PredictionModel(32, 100, 2, 32, 32, 32, 0.00002) -> 0.036101
PredictionModel(32, 100, 2, 32, 32, 32, 0.00003) -> 0.044811
PredictionModel(32, 100, 2, 32, 32, 32, 0.00004) -> 0.049592

PredictionModel(32, 100, 2, 32, 32, 32, 0.00005) -> 0.052581
PredictionModel(32, 100, 2, 32, 32, 32, 0.00006) -> 0.055665
PredictionModel(32, 100, 2, 32, 32, 32, 0.00007) -> 0.053718
PredictionModel(32, 100, 2, 32, 32, 32, 0.00008) -> 0.054870
PredictionModel(32, 100, 2, 32, 32, 32, 0.00009) -> 0.053259
PredictionModel(32, 100, 2, 32, 32, 32, 0.00010) ->  0.053668

PredictionModel(32, 100, 2, 32, 32, 32, 0.00020) ->  0.049492
PredictionModel(32, 100, 2, 32, 32, 32, 0.00030) ->  0.043739
PredictionModel(32, 100, 2, 32, 32, 32, 0.00040) ->  0.028401
PredictionModel(32, 100, 2, 32, 32, 32, 0.00050) ->  0.007170
PredictionModel(32, 100, 2, 32, 32, 32, 0.00060) ->  0.053259
PredictionModel(32, 100, 2, 32, 32, 32, 0.00070) ->  0.000561
PredictionModel(32, 100, 2, 32, 32, 32, 0.00080) -> -0.039655
PredictionModel(32, 100, 2, 32, 32, 32, 0.00100) -> -0.017807
PredictionModel(32, 100, 2, 32, 32, 32, 0.00500) -> -0.294112
PredictionModel(32, 100, 2, 32, 32, 32, 0.01000) -> -0.362064


PredictionModel(32, 50, 1, 32, 32, 32, 0.00008) -> 0.050720
PredictionModel(32, 100, 1, 32, 32, 32, 0.00008) -> 0.055049
PredictionModel(32, 150, 1, 32, 32, 32, 0.00008) -> 0.052136
PredictionModel(32, 200, 1, 32, 32, 32, 0.00008) -> 0.044620

# Gemini tests here
PredictionModel(32, 100, 1, 32, 4, 4, 0.00008) -> 0.056139
PredictionModel(32, 100, 1, 32, 16, 16, 0.00008) -> 0.057789
PredictionModel(32, 100, 1, 32, 64, 64, 0.00008) -> 0.042648
PredictionModel(32, 100, 1, 32, 128, 128, 0.00008) -> 0.014154

PredictionModel(32, 100, 1, 32, 8, 8, 0.00008) -> 0.060410
PredictionModel(32, 100, 1, 32, 16, 16, 0.00008) -> 0.057789
PredictionModel(32, 100, 1, 32, 24, 24, 0.00008) -> 0.057498
PredictionModel(32, 100, 1, 32, 32, 32, 0.00008) -> 0.053923

PredictionModel(32, 50, 1, 32, 8, 8, 0.00008) -> 0.049653
PredictionModel(32, 100, 1, 32, 8, 8, 0.00008) -> 0.062253
PredictionModel(32, 150, 1, 32, 8, 8, 0.00008) -> 0.064419
PredictionModel(32, 200, 1, 32, 8, 8, 0.00008) -> 0.064721

PredictionModel(32, 200, 1, 32, 8, 8, 0.00008) -> 0.065557
PredictionModel(32, 200, 2, 32, 8, 8, 0.00008) -> 0.065274
PredictionModel(32, 200, 3, 32, 8, 8, 0.00008) -> 0.064257
PredictionModel(32, 250, 1, 32, 8, 8, 0.00008) -> 0.066844

PredictionModel(32, 250, 1, 32, 8, 8, 0.00008) -> 0.066916
PredictionModel(32, 350, 1, 32, 8, 8, 0.00008) -> 0.066873
PredictionModel(32, 450, 1, 32, 8, 8, 0.00008) -> 0.066108
PredictionModel(32, 500, 1, 32, 8, 8, 0.00008) -> 0.065308

PredictionModel(32, 250, 1, 32, 8, 8, 0.00011) -> 0.067842
PredictionModel(32, 250, 1, 32, 8, 8, 0.00012) -> 0.067791
PredictionModel(32, 250, 1, 32, 8, 8, 0.00013) -> 0.068221
PredictionModel(32, 250, 1, 32, 8, 8, 0.00014) -> 0.067754
PredictionModel(32, 250, 1, 32, 8, 8, 0.00015) -> 0.068000

PredictionModel(32, 250, 1, 32, 8, 8, 0.000125) -> 0.066896
PredictionModel(32, 250, 1, 32, 8, 8, 0.00013) -> 0.068291
PredictionModel(32, 250, 1, 32, 8, 8, 0.000135) -> 0.067114
PredictionModel(32, 200, 1, 32, 8, 8, 0.00013) -> 0.068509
PredictionModel(32, 300, 1, 32, 8, 8, 0.00013) -> 0.067568

PredictionModel(32, 175, 1, 32, 8, 8, 0.00013) -> 0.068273
PredictionModel(32, 225, 1, 32, 8, 8, 0.00013) -> 0.068296
PredictionModel(32, 200, 1, 32, 8, 8, 0.000128) -> 0.068694
PredictionModel(32, 200, 1, 32, 8, 8, 0.000132) -> 0.067864
PredictionModel(32, 200, 2, 32, 8, 8, 0.00013) -> 0.067044

PredictionModel(32, 200, 1, 32, 16, 16, 0.000128) -> 0.050594
PredictionModel(32, 200, 1, 32, 4, 4, 0.000128) -> 0.077686
PredictionModel(32, 150, 1, 32, 8, 8, 0.000128) -> 0.068578
PredictionModel(32, 250, 1, 32, 8, 8, 0.000128) -> 0.067311
PredictionModel(32, 200, 2, 32, 8, 8, 0.000128) -> 0.067878

PredictionModel(32, 200, 1, 32, 2, 2, 0.000128) -> 0.095563
PredictionModel(32, 200, 1, 32, 6, 6, 0.000128) -> 0.066809
PredictionModel(32, 200, 1, 32, 4, 4, 0.000125) -> 0.077047
PredictionModel(32, 200, 1, 32, 4, 4, 0.00013) -> 0.077764
PredictionModel(32, 200, 2, 32, 4, 4, 0.000128) -> 0.075967

PredictionModel(32, 200, 1, 32, 2, 2, 0.000128) -> 0.098434

PredictionModel(32, 200, 2, 32, 2, 2, 0.000128) -> 0.093590
PredictionModel(32, 200, 3, 32, 2, 2, 0.000128) -> 0.086284
PredictionModel(32, 200, 4, 32, 2, 2, 0.000128) -> 0.082529
PredictionModel(32, 200, 5, 32, 2, 2, 0.000128) -> 0.078437

# Dropout Rate Test
PredictionModel(dropout=0.2) -> 0.100769