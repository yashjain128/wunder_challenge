import os
import sys
import numpy as np
import torch
import torch.nn as nn

# Set seeds for reproducibility
np.random.seed(0)
torch.manual_seed(0)

from utils import DataPoint, ScorerStepByStep

class LSTMModel(nn.Module):
    """
    LSTMModel definition.
    It takes a sequence of data points and predicts the next data point.
    """
    def __init__(self, input_dim, hidden_dim, layer_dim, output_dim, dropout):
        super(LSTMModel, self).__init__()
        self.hidden_dim = hidden_dim
        self.layer_dim = layer_dim
        self.lstm = nn.LSTM(input_dim, hidden_dim, layer_dim, batch_first=True, dropout=dropout)
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        h0 = torch.zeros(self.layer_dim, x.size(0), self.hidden_dim).to(x.device)
        c0 = torch.zeros(self.layer_dim, x.size(0), self.hidden_dim).to(x.device)
        out, _ = self.lstm(x, (h0, c0))
        out = self.fc(out)
        return out

class PredictionModel:
    """
    Prediction model using an LSTM.
    The model is retrained for each new sequence.
    """
    def __init__(self, input_dim=32, hidden_dim=200, layer_dim=2, output_dim=32, input_seq_len=2, output_seq_len=2, lr=0.000128, dropout=0.0001):
        self.current_seq_ix = -1
        self.sequence_history = []
        self.prediction_cache = []
        
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.layer_dim = layer_dim
        self.output_dim = output_dim
        self.input_seq_len = input_seq_len
        self.output_seq_len = output_seq_len
        self.lr = lr
        self.dropout = dropout
        
        self._reset_model()

    def _reset_model(self):
        """Initializes a new model, criterion, and optimizer."""
        self.model = LSTMModel(self.input_dim, self.hidden_dim, self.layer_dim, self.output_dim, self.dropout)
        self.criterion = nn.MSELoss()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lr)

    def predict(self, data_point: DataPoint) -> np.ndarray:
        if self.current_seq_ix != data_point.seq_ix:
            self.current_seq_ix = data_point.seq_ix
            self.sequence_history = []
            self.prediction_cache = []
            self._reset_model()

        self.sequence_history.append(data_point.state.copy())

        # Online training step
        if len(self.sequence_history) >= self.input_seq_len + self.output_seq_len:
            # Create a single training sample from the most recent data
            x_train = np.array(self.sequence_history[-(self.input_seq_len + self.output_seq_len):-self.output_seq_len])
            y_train = np.array(self.sequence_history[-self.output_seq_len:])
            
            trainX = torch.tensor(x_train, dtype=torch.float32).reshape(1, self.input_seq_len, self.input_dim)
            trainY = torch.tensor(y_train, dtype=torch.float32).reshape(1, self.output_seq_len, self.output_dim)

            self.model.train()
            self.optimizer.zero_grad()
            outputs = self.model(trainX)
            loss = self.criterion(outputs, trainY)
            loss.backward()
            self.optimizer.step()

        if not data_point.need_prediction:
            return None

        if self.prediction_cache:
            return self.prediction_cache.pop(0)

        # Generate new predictions if cache is empty
        if len(self.sequence_history) < self.input_seq_len:
            return np.mean(self.sequence_history, axis=0)

        self.model.eval()
        with torch.no_grad():
            last_sequence = np.array(self.sequence_history[-self.input_seq_len:]).reshape(1, self.input_seq_len, self.input_dim)
            input_tensor = torch.tensor(last_sequence, dtype=torch.float32)
            
            # The model now predicts a sequence of 32 points
            predictions_seq = self.model(input_tensor).numpy().flatten()
            
            # The output of the model is (1, 32, 32), flatten gives a 1024 array.
            # We need to split it into 32 arrays of 32.
            self.prediction_cache = np.split(predictions_seq, self.output_seq_len)
            
            return self.prediction_cache.pop(0)

def test_model(model, scorer):
        # Evaluate our solution
        results = scorer.score(model)

        print("\nResults:")
        print(f"Mean R² across all features: {results['mean_r2']:.6f}")
        ##print("\nR² for first 5 features:")
        ##for i in range(min(5, len(scorer.features))):
            ##feature = scorer.features[i]
            ##print(f"  {feature}: {results[feature]:.6f}")


if __name__ == "__main__":
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    # Define the path to the training data
    test_file = os.path.join(CURRENT_DIR, "..", "datasets", "train.parquet")

    # Check if the test file exists
    if not os.path.exists(test_file):
        print(f"Error: Test file not found at {test_file}")
    else:
        # Create and test our model

        # Load data into scorer
        scorer = ScorerStepByStep(test_file)

        print("Testing LSTM model...")
        print(f"Feature dimensionality: {scorer.dim}")
        print(f"Number of rows in dataset: {len(scorer.dataset)}")
        print(f"\nTotal features: {len(scorer.features)}")

        model = PredictionModel(dropout=0.2)
        test_model(model, scorer)

        print("\n" + "=" * 60)
        print("Try submitting an archive with solution.py file")
        print("to test the solution submission mechanism!")
        print("=" * 60)


