import os
import numpy as np
import torch
import torch.nn as nn
import pandas as pd
from torch.utils.data import TensorDataset, DataLoader

# Set seeds for reproducibility
np.random.seed(0)
torch.manual_seed(0)

class LSTMModel(nn.Module):
    """
    LSTMModel definition.
    It takes a sequence of data points and predicts the next data point.
    """
    def __init__(self, input_dim, hidden_dim, layer_dim, output_dim, dropout):
        super(LSTMModel, self).__init__()
        self.hidden_dim = hidden_dim
        self.layer_dim = layer_dim
        self.lstm = nn.LSTM(input_dim, hidden_dim, layer_dim, batch_first=True, dropout=dropout)
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        h0 = torch.zeros(self.layer_dim, x.size(0), self.hidden_dim).to(x.device)
        c0 = torch.zeros(self.layer_dim, x.size(0), self.hidden_dim).to(x.device)
        out, _ = self.lstm(x, (h0, c0))
        out = self.fc(out)
        return out

def create_sequences(data, input_seq_len, output_seq_len):
    xs, ys = [], []
    for i in range(len(data) - input_seq_len - output_seq_len):
        x = data[i:(i + input_seq_len)]
        y = data[(i + input_seq_len):(i + input_seq_len + output_seq_len)]
        xs.append(x)
        ys.append(y)
    return np.array(xs), np.array(ys)

def main():
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
    # Define the path to the training data
    data_file = os.path.join(CURRENT_DIR, "..", "datasets", "train.parquet")

    # Check if the data file exists
    if not os.path.exists(data_file):
        print(f"Error: Data file not found at {data_file}")
        return

    # Load the data
    df = pd.read_parquet(data_file)
    
    # For simplicity, we'll treat all sequences as one long sequence.
    # A more advanced approach would be to handle each sequence separately.
    feature_columns = [col for col in df.columns if col not in ['seq_ix', 'step_in_seq', 'need_prediction']]
    data = df[feature_columns].values

    # Hyperparameters
    input_dim = len(feature_columns)
    hidden_dim = 200
    layer_dim = 2
    output_dim = len(feature_columns)
    input_seq_len = 32
    output_seq_len = 32
    lr = 0.000128
    dropout = 0.2
    num_epochs = 10
    batch_size = 64

    # Create sequences
    X, y = create_sequences(data, input_seq_len, output_seq_len)

    # Create datasets and dataloaders
    train_data = TensorDataset(torch.from_numpy(X).float(), torch.from_numpy(y).float())
    train_loader = DataLoader(train_data, shuffle=True, batch_size=batch_size)

    # Initialize model, criterion, and optimizer
    model = LSTMModel(input_dim, hidden_dim, layer_dim, output_dim, dropout)
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    # Training loop
    for epoch in range(num_epochs):
        for i, (sequences, labels) in enumerate(train_loader):
            model.train()
            optimizer.zero_grad()
            outputs = model(sequences)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            if (i + 1) % 100 == 0:
                print(f'Epoch [{epoch+1}/{num_epochs}], Step [{i+1}/{len(train_loader)}], Loss: {loss.item():.4f}')

    # Save the model
    model_path = os.path.join(CURRENT_DIR, "lstm_model.pth")
    torch.save(model.state_dict(), model_path)
    print(f"Model saved to {model_path}")

if __name__ == "__main__":
    main()
